#include "HashTable.h"
#include <iostream>

int main()
{
    KeyedHashTable ht;
    ht.Print();
}